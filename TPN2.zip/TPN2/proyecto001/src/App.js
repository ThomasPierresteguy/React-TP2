import './App.css';

function App() {
  return (
    <div>
      <form onSubmit={presion}>
        <p>Ingrese el mensaje:
          <input type="text" name="mensaje" />
        </p>
        <p>
          <input type="submit" value="Mostrar mensaje" />
        </p>
      </form>
    </div>
  );
}

function presion(e) {
  e.preventDefault();
  const msj=e.target.mensaje.value;
  alert('El mensaje es: '+msj);
}

export default App;